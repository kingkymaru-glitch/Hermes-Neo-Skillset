---
name: elegant-web-design-language
description: MARU premium web bar. Use on awesome/classy/elegant asks.
---

# Elegant Web Design Language (MARU's "awesome" bar)

Learned from ~/Desktop/mckinsey_fusion_hero.html — the founder's explicit reference for
premium feel. Internalize and apply by default whenever he says "awesome / classy /
elegant / McKinsey-grade" or a redesign where polish matters.

## PALETTE (dark, editorial, restrained — NOT techy-neon)
- Base ink: #030508 (near-black, not pure black)
- Layered navy: #0A1628 / #111E2E / #1E2D3F (backgrounds, not flat fills)
- Warm ivory text: #F0EBE3 (warm off-white, never clinical #fff)
- Ivory dim (body): rgba(240,235,227,0.6)
- GOLD accent (the ONE hero accent): #C9A96E, gold-dim rgba(201,169,110,0.4)
- Cyan only SUBORDINATE tech accent: #5BA4B4 / #7DD3E8
RULE: warm metallic gold as primary accent. Cool cyan subordinate. AVOID neon
#00e5c3 / #2f9bff as primary — too cheap/techy for this bar.

## TYPOGRAPHY (serif/sans contrast = editorial luxury)
- Display/headlines: Cormorant Garamond, weight 300/400, clamp(2rem,5vw,4.5rem),
  line-height 1.05-1.15, slight negative letter-spacing. Italic serif <em> in GOLD for emphasis.
- Body/labels: Inter, weight 300-400, line-height 1.7-1.8, ivory-dim.
- Eyebrows/labels: JetBrains Mono, 0.6-0.65rem, letter-spacing 0.2-0.25em, UPPERCASE, gold.
  Often prefixed with a rule line or "01 —".
- Load: Google Fonts Cormorant Garamond + Inter + JetBrains Mono.

## MOTION (the soul of "elegant")
- Reveals: opacity 0→1 + translateY(20-40px)→0, ease power3.out / cubic-bezier(0.25,0.46,0.45,0.94),
  duration 0.8-1.2s, staggered.
- Headlines: line-mask reveal — text starts translateY(110%) inside overflow:hidden line,
  slides up. Feels like type rising into frame.
- Scroll: GSAP ScrollTrigger, toggleActions 'play none none none', start 'top 75-85%'.
  Cards stagger; counters animate 0→target with a thin gold bar filling.
- Ambient: slow rotations (time*0.05), breathing scale (1+sin*0.05), mouse parallax (lerp 0.03).
  Subtle, never distracting.
- Hover: gold underline width 0→100%; buttons lift translateY(-2px).

## COMPOSITION / DETAIL
- Generous whitespace, max-width ~1200px, 8vw side padding.
- Thin hairline rules (1px ivory-faint rgba(...,0.15)) as dividers + top accents.
- Grain overlay (fixed, opacity 0.03, SVG fractalNoise) for filmic texture.
- Rhythm: eyebrow + serif headline + dim body + gold CTA, repeated per section.
- Stats: huge serif gold number + suffix, thin gold fill bar.

## APPLY TO LUNAV LABS (current Vite+Cesium project at ~/lunav-labs)
Existing page uses cyan/blue + Inter only + plain reveals. To hit this bar:
1. Re-theme CSS vars → ink/navy/gold/ivory. Keep Cesium globe; tint its labels gold, warm the veil.
2. Headlines → Cormorant Garamond (light); body Inter 300; eyebrows JetBrains Mono.
3. Ghost project names → serif, gold stroke/fill (not cyan stroke).
4. Add grain overlay + hairline dividers + gold nav/links.
5. KEEP the scroll dolly-out globe (signature interaction) — just warm it.
6. Reveals → line-mask headlines, staggered cards, gold bar fills.
7. CTAs → gold solid (ink text), hover lift.
Elegance = restraint + perfect easing, NOT more effects. Do not over-animate.
