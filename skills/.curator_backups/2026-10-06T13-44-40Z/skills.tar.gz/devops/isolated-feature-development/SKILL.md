---
name: isolated-feature-development
description: "Isolated feature dev with separate backend on localhost."
---

# Isolated Feature Development

## Trigger

Starting a new feature, module, or product line that must not touch production data or deploy until complete.

## Hard Gates

1. **Discuss first, no code** — do not write implementation code until the user approves the design/logic. Present options, trade-offs, and the control surface. Await explicit "go" before any code.
2. **Feature-first, not schema-first** — build working software first; schema emerges from real feature needs, not a design document.
3. **Backend isolation** — use a separate Supabase project per feature/module. Never reuse the production Supabase project for development.
4. **Local-first** — run everything on localhost. Push to GitHub for record only. Do not merge to main or trigger deploys during development.

## Workflow

### 1. Design Discussion
- Present the feature scope, UX, data flow, and control surface.
- Do not write code until the user signs off.

### 2. Supabase Isolation
- Create a new Supabase project (free tier is fine).
- Link local Supabase CLI:
  ```bash
  cd <feature-repo>
  supabase init --project-id <short-id>
  supabase link --project-ref <project-ref>
  ```
- Create `.env.local` pointing to the new Supabase project.

### 3. Repository Setup
- Work on a feature branch: `feature/<name>` or `arras/<feature-name>`
- Do not push to main during active development.
- If the repo is connected to a deploy platform, pause Git integration or use skip markers to prevent deploys.

### 4. Build and Verify Locally
- Run the app on localhost.
- Verify the feature works before pushing.
- Push the branch to GitHub for record only.

### 5. Schema Changes
- Write SQL migration files in `supabase/migrations/` with date prefix.
- Apply via `supabase db push` only when the schema is needed for the feature.
- Do not write speculative schema for features not yet built.

### 6. Merge Only When Ready
- Only merge to main and enable deploys when the feature is complete and verified.
- Do not leave half-built features on main.

## Pitfalls

- **Implicit model selection**: do not auto-switch models or data sources between tabs. Use explicit user selection instead.
- **Schema-first trap**: avoid designing full schema upfront. It becomes useless when the actual feature shapes it differently.
- **Production pollution**: never run migrations or seed data against the production Supabase during development.
- **Accidental deploy**: feature branches connected to deploy platforms will create preview deploys. Disable Git integration or use skip markers.
